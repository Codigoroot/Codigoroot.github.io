<?php 
require_once "../modelos/Clientes.php";

$clientes=new Clientes();

$Id=isset($_POST["Id"])? limpiarCadena($_POST["Id"]):"";
$Nombre= isset($_POST["Nombre"])? limpiarCadena($_POST["Nombre"]):"";
$Calle=isset($_POST["Calle"])? limpiarCadena($_POST["Calle"]):"";
$Telefono=isset($_POST["Telefono"])? limpiarCadena($_POST["Telefono"]):"";
$CorreoS=isset($_POST["Correo"])? limpiarCadena($_POST["Correo"]):"";








switch ($_GET["op"]) {
	case 'guardaryeditar':
	$nombre1 =ucwords(strtolower($_POST['Nombre'])); 

	$calles = ucwords(strtolower($_POST['Calle']));
	$Correo = strtolower($_POST['Correo']);


	if (empty($Id)) {
		$rspta=$clientes->insertar($nombre1,$calles,$Telefono,$Correo);
		echo $rspta ? "Datos registrados correctamente" : "No se pudo registrar los datos";
	}else{
         $rspta=$clientes->editar($Id,$nombre1,$calles,$Telefono,$Correo);
		echo $rspta ? "Datos actualizados correctamente" : "No se pudo actualizar los datos";
	}
		break;
	

	case 'desactivar':
		$rspta=$clientes->desactivar($Id);
		echo $rspta ? "Datos desactivados correctamente" : "No se pudo desactivar los datos";
		break;
	case 'activar':
		$rspta=$clientes->activar($Id);
		echo $rspta ? "Datos activados correctamente" : "No se pudo activar los datos";
		break;
	
	case 'mostrar':
		$rspta=$clientes->mostrar($Id);
		echo json_encode($rspta);
		break;

    case 'listar':
		$rspta=$clientes->listar();
		$data=Array();

		while ($reg=$rspta->fetch_object()) {
			$data[]=array(
            "0"=>($reg->condicion)?

            '<button class="btn btn-warning btn-xs" onclick="mostrar('.$reg->Id.')"><i class="fa fa-pencil"></i></button>'. ' '.'<button class="btn btn-danger btn-xs" onclick="desactivar('.$reg->Id.')"><i class="fa fa-close"></i></button>'   :'<button class="btn btn-warning btn-xs" onclick="mostrar('.$reg->Id.')"><i class="fa fa-pencil"></i></button>'  .' '.'<button class="btn btn-primary btn-xs" onclick="activar('.$reg->Id.')"><i class="fa fa-check"></i></button>',

            
            "1"=>$reg->Nombre,
            "2"=>$reg->Telefono,
            "3"=>$reg->Calle, 
            "4"=>$reg->Correo,        
            "5"=>($reg->condicion)?'<span class="label bg-green">Activado</span>':'<span class="label bg-red">Desactivado</span>'
              );
		}
		$results=array(
             "sEcho"=>1,//info para datatables
             "iTotalRecords"=>count($data),//enviamos el total de registros al datatable
             "iTotalDisplayRecords"=>count($data),//enviamos el total de registros a visualizar
             "aaData"=>$data); 
		echo json_encode($results);
		break;

	case 'selectEstado':
			require_once "../modelos/Estado.php";
			$estado=new Estado();

			$rspta=$estado->select();
			echo '<option value="">Selecciona una estado</option>';
			while ($reg=$rspta->fetch_object()) {
				echo '<option value=' . $reg->idE.'>'.$reg->nombre.'</option>';
			}
			break;

/**
		case 'selectMunicipios':
			require_once "../modelos/Estado.php";
			$estado=new Estado();

			$rspta=$estado->selectMunicipio();

			while ($reg=$rspta->fetch_object()) {
				echo '<option value=' . $reg->idM.'>'.$reg->nombre.'</option>';
			}
			break;

		case 'selectLocalidad':
			require_once "../modelos/Estado.php";
			$estado=new Estado();

			$rspta=$estado->selectLocalidad();

			while ($reg=$rspta->fetch_object()) {
				echo '<option value=' . $reg->idL.'>'.$reg->nombre.'</option>';
			}
			break;
*/

 
}
 ?>