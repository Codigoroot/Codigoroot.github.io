<?php 
require_once "../modelos/Marca.php";

$marca=new Marca();

$IdMarca=isset($_POST["IdMarca"])? limpiarCadena($_POST["IdMarca"]):"";
$Nombre=isset($_POST["Nombre"])? limpiarCadena($_POST["Nombre"]):"";



switch ($_GET["op"]) {
	case 'guardaryeditar':
		$Nombremarca = strtoupper($_POST['Nombre']);


	if (empty($IdMarca)) {
		$rspta=$marca->insertar($Nombremarca);
		echo $rspta ? "Datos registrados correctamente" : "No se pudo registrar los datos";
	}else{
         $rspta=$marca->editar($IdMarca,$Nombremarca);
		echo $rspta ? "Datos actualizados correctamente" : "No se pudo actualizar los datos";
	}
		break;
	

	case 'desactivar':
		$rspta=$marca->desactivar($IdMarca);
		echo $rspta ? "Datos desactivados correctamente" : "No se pudo desactivar los datos";
		break;
	case 'activar':
		$rspta=$marca->activar($IdMarca);
		echo $rspta ? "Datos activados correctamente" : "No se pudo activar los datos";
		break;
	
	case 'mostrar':
		$rspta=$marca->mostrar($IdMarca);
		echo json_encode($rspta);
		break;

    case 'listar':
		$rspta=$marca->listar();
		$data=Array();

		while ($reg=$rspta->fetch_object()) {
			$data[]=array(
            "0"=>($reg->condicion)?'<button class="btn btn-warning btn-xs" onclick="mostrar('.$reg->IdMarca.')"><i class="fa fa-pencil"></i></button>'.' '.'<button class="btn btn-danger btn-xs" onclick="desactivar('.$reg->IdMarca.')"><i class="fa fa-close"></i></button>':'<button class="btn btn-warning btn-xs" onclick="mostrar('.$reg->IdMarca.')"><i class="fa fa-pencil"></i></button>'.' '.'<button class="btn btn-primary btn-xs" onclick="activar('.$reg->IdMarca.')"><i class="fa fa-check"></i></button>',
            "1"=>$reg->Nombre,
            "2"=>($reg->condicion)?'<span class="label bg-green">Activado</span>':'<span class="label bg-red">Desactivado</span>'
              );
		}
		$results=array(
             "sEcho"=>1,//info para datatables
             "iTotalRecords"=>count($data),//enviamos el total de registros al datatable
             "iTotalDisplayRecords"=>count($data),//enviamos el total de registros a visualizar
             "aaData"=>$data); 
		echo json_encode($results);
		break;

		case 'selectCategoria':
			require_once "../modelos/Categoria.php";
			$categoria=new Categoria();

			$rspta=$categoria->select();

			while ($reg=$rspta->fetch_object()) {
				echo '<option value=' . $reg->idcategoria.'>'.$reg->nombre.'</option>';
			}
			break;
}
 ?>