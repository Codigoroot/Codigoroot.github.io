<?php 
require_once "../modelos/Consultas.php";

$consulta = new Consultas();

switch ($_GET["op"]) {
	

    case 'reportesporfecha':
    $fecha_inicio=$_REQUEST["fecha_inicio"];
    $fecha_fin=$_REQUEST["fecha_fin"];

		$rspta=$consulta->reportesporfecha($fecha_inicio,$fecha_fin);
		$data=Array();

		while ($reg=$rspta->fetch_object()) {
			$data[]=array(
            "0"=>$reg->Id,
            "1"=>$reg->fecha,
            "2"=>$reg->cliente,
            "3"=>$reg->articulos,
            "4"=>$reg->marcas,
            "5"=>$reg->modelos,
            "6"=>$reg->diagnostico,
            "7"=>$reg->fechaSalida,
            "8"=>$reg->estado,
            "9"=>$reg->costo,
              );
		}
		$results=array(
             "sEcho"=>1,//info para datatables
             "iTotalRecords"=>count($data),//enviamos el total de registros al datatable
             "iTotalDisplayRecords"=>count($data),//enviamos el total de registros a visualizar
             "aaData"=>$data); 
		echo json_encode($results);
		break;

     case 'reportespormarca':
    $fecha_inicio=$_REQUEST["fecha_inicio"];
    $fecha_fin=$_REQUEST["fecha_fin"];
    $idMarca=$_REQUEST["idMarca"];

        $rspta=$consulta->reportespormarca($fecha_inicio,$fecha_fin,$idMarca);
        $data=Array();

        while ($reg=$rspta->fetch_object()) {
            $data[]=array(
             "0"=>$reg->Id,
            "1"=>$reg->fecha,
            "2"=>$reg->cliente,
            "3"=>$reg->articulos,
            "4"=>$reg->marcas,
            "5"=>$reg->modelos,
            "6"=>$reg->diagnostico,
            "7"=>$reg->fechaSalida,
            "8"=>$reg->estado,
            "9"=>$reg->costo,
              );
        }
        $results=array(
             "sEcho"=>1,//info para datatables
             "iTotalRecords"=>count($data),//enviamos el total de registros al datatable
             "iTotalDisplayRecords"=>count($data),//enviamos el total de registros a visualizar
             "aaData"=>$data); 
        echo json_encode($results);
        break;
}
 ?>