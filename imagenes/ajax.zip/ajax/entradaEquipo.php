<?php 

session_start();
$nom=$_SESSION['nombre'];

$ape=$_SESSION['tipo_documento'];

date_default_timezone_set('America/Mexico_City');
$fecha = date("Y-m-d ");

require_once "../modelos/EntradaEquipo.php";




$entradaEquipo=new EntradaEquipo();

$Id=isset($_POST["Id"])? limpiarCadena($_POST["Id"]):"";
$IdCliente=isset($_POST["IdCliente"])? limpiarCadena($_POST["IdCliente"]):"";
$IdArticulo=isset($_POST["IdArticulo"])? limpiarCadena($_POST["IdArticulo"]):"";
$IdMarca=isset($_POST["IdMarca"])? limpiarCadena($_POST["IdMarca"]):"";
$control_modelo=isset($_POST["control_modelo"])? limpiarCadena($_POST["control_modelo"]):"";
$Color=isset($_POST["Color"])? limpiarCadena($_POST["Color"]):"";
$Serie=isset($_POST["Serie"])? limpiarCadena($_POST["Serie"]):"";
$fechaRecepcion=$fecha;
$Accesorios=isset($_POST["Accesorios"])? limpiarCadena($_POST["Accesorios"]):"";
$diagnostico=isset($_POST["diagnostico"])? limpiarCadena($_POST["diagnostico"]):"";


$nom1 = $nom. " " . $ape;

switch ($_GET["op"]) {
	case 'guardaryeditar':


	$Color1 = strtoupper($_POST['Color']);
	$Serie1 = strtoupper($_POST['Serie']);
	$Accesorios1 = strtoupper($_POST['Accesorios']);
	$diagnostico1 = ucfirst(strtolower($_POST['diagnostico']));
	//$diagnostico1 = ucfirst(strtolower($diagnostico));


	
	if (empty($Id)) {
		$rspta=$entradaEquipo->insertar($IdCliente,$IdArticulo,$IdMarca,$control_modelo,$Color1,$Serie1,$fechaRecepcion,$Accesorios1,$diagnostico1,$nom1);
		echo $rspta ? "Datos registrados correctamente" : "No se pudo registrar los datos";
	}else{
         $rspta=$entradaEquipo->editar($Id,$IdCliente,$IdArticulo,$IdMarca,$control_modelo,$Color1,$Serie1,$fechaRecepcion,$Accesorios1,$diagnostico1,$nom1);
		echo $rspta ? "Datos actualizados correctamente" : "No se pudo actualizar los datos";
	}
		break;
	

	case 'desactivar':
		$rspta=$entradaEquipo->desactivar($Id);
		echo $rspta ? "Datos desactivados correctamente" : "No se pudo desactivar los datos";
		break;
	case 'activar':
		$rspta=$entradaEquipo->activar($Id);
		echo $rspta ? "Datos activados correctamente" : "No se pudo activar los datos";
		break;
	
	case 'mostrar':
		$rspta=$entradaEquipo->mostrar($Id);
		echo json_encode($rspta);
		break;

	

    case 'listar':
		$rspta=$entradaEquipo->listar();
		$data=Array();

		while ($reg=$rspta->fetch_object()) {
		
                 	$url='../reportes/exFactura.php?id=';
                 	
             
                  
                 
			$data[]=array(
            "0"=>($reg->condicion)?

            	'<button class="btn btn-warning btn-xs" onclick="mostrar('.$reg->Id.')" >
            	<i class="fa fa-pencil"></i></button>'.'

            '.' <a target="_blank" href="'.$url.$reg->Id.'"> <button class="btn btn-danger btn-xs"><i class="fa fa-file-pdf-o"></i></button></a> '.'

            '.' <button class="btn btn-primary btn-xs" onclick="listar1('.$reg->Id.')">
				<i class="fa fa-file"></i></button>' 

            :'<button class="btn btn-warning btn-xs" onclick="mostrar('.$reg->Id.')">
            <i class="fa fa-pencil"></i></button>'.'

            '.' <a target="_blank" href="'.$url.$reg->Id.'"> <button class="btn btn-danger btn-xs"><i class="fa fa-file-pdf-o"></i></button></a> '.'

            '.' <button class="btn btn-primary btn-xs" onclick="listar1('.$reg->Id.')">
				<i class="fa fa-file"></i></button>' ,


            "1"=>'<h4><center><span class="label bg-black">'.$reg->Id.'</span></center></h4>',
            "2"=>$reg->cliente,
            "3"=>$reg->articulos,
            "4"=>$reg->marcas,
            "5"=>$reg->modelos,
            "6"=>$reg->fechaRecepcion, 
            "7"=>$reg->diagnostico,  
            "8"=>($reg->Estado== 'Recibido')?'<h4><span class="label bg-red"> Sin revisar <i class="fa fa-window-close-o" aria-hidden="true"></i></span></h4>':
				(($reg->Estado=='En Proceso')?'<h4><span class="label bg-yellow">'.$reg->Estado.'  <i class="fa fa-cog fa-spin fa-1x fa-fw"></i> </span></h4>':
				(($reg->Estado=='Terminado')?'<h4><span class="label bg-blue"> ' .$reg->Estado.' <i class="fa fa-check-square-o"></i></span></h4>':	
				(($reg->Estado=='Entregado')?'<h4><span class="label bg-green"> '. $reg->Estado.' <i class="fa fa-check" aria-hidden="true"></i></span></h4>':
				'<span class="label bg-red">'.$reg->Estado.' </span>'))));
		}

		$results=array(
             "sEcho"=>1,//info para datatables
             "iTotalRecords"=>count($data),//enviamos el total de registros al datatable
             "iTotalDisplayRecords"=>count($data),//enviamos el total de registros a visualizar
             "aaData"=>$data); 
		echo json_encode($results);
		break;



		case 'kardex1':
		$rspta=$entradaEquipo->kardex($Id);
		$data=Array();

		while ($reg=$rspta->fetch_object()) {
	
                 	
             
                  
                 
			$data[]=array(
            "0"=>($reg->ide),


            "1"=>'<span class="label bg-green"> '.$reg->nom.'	</span>',
            "2"=>$reg->descrip,
            "3"=>$reg->fecha,
            
              );
		}

		$results=array(
             "sEcho"=>1,//info para datatables
             "iTotalRecords"=>count($data),//enviamos el total de registros al datatable
             "iTotalDisplayRecords"=>count($data),//enviamos el total de registros a visualizar
             "aaData"=>$data); 
		echo json_encode($results);
		break;

	case 'selectCliente':
			require_once "../modelos/Entrada.php";
			$entrada=new Entrada();

			$rspta=$entrada->selectCliente();
			echo '<option value="">Selecciona un cliente</option>';
			while ($reg=$rspta->fetch_object()) {
				echo '<option value=' . $reg->Id.'>'.$reg->Nombre.'</option>';
			}
			break;

/**
	case 'selectTelefono':
			require_once "../modelos/Entrada.php";
			$entrada=new Entrada();

			$rspta=$entrada->selectTelefono();

			while ($reg=$rspta->fetch_object()) {
				echo '<option value=' . $reg->Id.'>'.$reg->Telefono.'</option>';
			}
			break;
*/
/*			case 'selectCorreo':
			require_once "../modelos/Entrada.php";
			$entrada=new Entrada();

			$rspta=$entrada->selectCorreo();

			while ($reg=$rspta->fetch_object()) {
				echo '<option value=' . $reg->Correo.'>'.$reg->Correo.'</option>';
			}
			break;
*/
			case 'selectArticulo':
			require_once "../modelos/Entrada.php";
			$entrada=new Entrada();

			$rspta=$entrada->selectArticulo(); echo '<option value="">Selecciona un
			articulo</option>'; while ($reg=$rspta->fetch_object()) { echo '<option
			value=' . $reg->idarticulo.'>'.$reg->nombre.'</option>'; } break;


			case 'selectMarca':
			require_once "../modelos/Entrada.php";
			$entrada=new Entrada();

			$rspta=$entrada->selectMarca();
			echo '<option value="">Selecciona una marca</option>';
			while ($reg=$rspta->fetch_object()) {
				echo '<option value=' . $reg->IdMarca.'>'.$reg->Nombre.'</option>';
			}
			break;

			case 'selectModelo':
			require_once "../modelos/Entrada.php";
			$entrada=new Entrada();

			$rspta=$entrada->selectModelo();

			while ($reg=$rspta->fetch_object()) {
				echo '<option value=' . $reg->Id.'>'.$reg->Nombre.'</option>';
			}
			break;

			case 'selectUsuario':
			require_once "../modelos/Entrada.php";
			$entrada=new Entrada();

			$rspta=$entrada->selectUsuario();
			echo '<option value="">Selecciona un usuario</option>';
			while ($reg=$rspta->fetch_object()) {
				echo '<option value=' . $reg->idusuario.'>'.$reg->nombre.'</option>';
			}
			break;


}
 ?>