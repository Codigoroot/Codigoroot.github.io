<?php 
require_once "../modelos/Modelo.php";

$modelo=new Modelo();

$Id=isset($_POST["Id"])? limpiarCadena($_POST["Id"]):"";
$Nombre=isset($_POST["Nombre"])? limpiarCadena($_POST["Nombre"]):"";
$idMarca=isset($_POST["idMarca"])? limpiarCadena($_POST["idMarca"]):"";





switch ($_GET["op"]) {
	case 'guardaryeditar':

	$NombreModelo = strtoupper($_POST['Nombre']);

	if (empty($Id)) {
		$rspta=$modelo->insertar($idMarca, $NombreModelo);
		echo $rspta ? "Datos registrados correctamente" : "No se pudo registrar los datos";
	}else{
         $rspta=$modelo->editar($Id,$idMarca,$NombreModelo);
		echo $rspta ? "Datos actualizados correctamente" : "No se pudo actualizar los datos";
	}
		break;
	

	case 'desactivar':
		$rspta=$modelo->desactivar($Id);
		echo $rspta ? "Datos desactivados correctamente" : "No se pudo desactivar los datos";
		break;
	case 'activar':
		$rspta=$modelo->activar($Id);
		echo $rspta ? "Datos activados correctamente" : "No se pudo activar los datos";
		break;
	
	case 'mostrar':
		$rspta=$modelo->mostrar($Id);
		echo json_encode($rspta);
		break;

    case 'listar':
		$rspta=$modelo->listar();
		$data=Array();

		while ($reg=$rspta->fetch_object()) {
			$data[]=array(
            "0"=>($reg->condicion)?'<button class="btn btn-warning btn-xs" onclick="mostrar('.$reg->Id.')"><i class="fa fa-pencil"></i></button>'.' '.'<button class="btn btn-danger btn-xs" onclick="desactivar('.$reg->Id.')"><i class="fa fa-close"></i></button>':'<button class="btn btn-warning btn-xs" onclick="mostrar('.$reg->Id.')"><i class="fa fa-pencil"></i></button>'.' '.'<button class="btn btn-primary btn-xs" onclick="activar('.$reg->Id.')"><i class="fa fa-check"></i></button>',
            "1"=>$reg->marcas,
            "2"=>$reg->Nombre,
            "3"=>($reg->condicion)?'<span class="label bg-green">Activado</span>':'<span class="label bg-red">Desactivado</span>'
              );
		}
		$results=array(
             "sEcho"=>1,//info para datatables
             "iTotalRecords"=>count($data),//enviamos el total de registros al datatable
             "iTotalDisplayRecords"=>count($data),//enviamos el total de registros a visualizar
             "aaData"=>$data); 
		echo json_encode($results);
		break;

		case 'selectMarca':
			require_once "../modelos/Marca.php";
			$marca=new Marca();

			$rspta=$marca->select();
					echo '<option value="">Selecciona una Marca</option>';
			while ($reg=$rspta->fetch_object()) {
				echo '<option value=' . $reg->IdMarca.'>'.$reg->Nombre.'</option>';
			}
			break;




}
 ?>