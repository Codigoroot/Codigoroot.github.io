<?php 
require_once "../modelos/Avance.php";

$avance=new Avance();

$Id=isset($_POST["Id"])? limpiarCadena($_POST["Id"]):"";
$Id_EntradaEquipo=isset($_POST["Id_EntradaEquipo"])? limpiarCadena($_POST["Id_EntradaEquipo"]):"";
$Descripcion=isset($_POST["Descripcion"])? limpiarCadena($_POST["Descripcion"]):"";
$Id_usuario=isset($_POST["Id_usuario"])? limpiarCadena($_POST["Id_usuario"]):"";
$Fecha=isset($_POST["Fecha"])? limpiarCadena($_POST["Fecha"]):"";
$Estado=isset($_POST["Estado"])? limpiarCadena($_POST["Estado"]):"";
$Costo=isset($_POST["Costo"])? limpiarCadena($_POST["Costo"]):"";


switch ($_GET["op"]) {


	case 'guardaryeditar':
	if (empty($Id)) {
		$rspta=$avance->insertar($Id_EntradaEquipo,$Id_usuario,$Fecha,$Descripcion);
		$rspta=$avance->insertarEstado($Id_EntradaEquipo,$Estado);
		$rspta=$avance->insertarCosto($Id_EntradaEquipo,$Costo);
		echo $rspta ? "Datos registrados correctamente" : "No se pudo registrar los datos";
	}else{
         $rspta=$avance->editar($Id,$Id_EntradaEquipo,$Id_usuario,$Fecha,$Descripcion);
         $rspta=$avance->insertarEstado($Id_EntradaEquipo,$Estado);
         $rspta=$avance->insertarCosto($Id_EntradaEquipo,$Costo);
		echo $rspta ? "Datos actualizados correctamente" : "No se pudo actualizar los datos";
	}
		break;


	



	case 'desactivar':
		$rspta=$avance->desactivar($Id);
		echo $rspta ? "Datos desactivados correctamente" : "No se pudo desactivar los datos";
		break;
	case 'activar':
		$rspta=$avance->activar($Id);
		echo $rspta ? "Datos activados correctamente" : "No se pudo activar los datos";
		break;
	
	case 'mostrar':
		$rspta=$avance->mostrar($Id);
		echo json_encode($rspta);
		break;

    case 'listar':
		$rspta=$avance->listar();
		$data=Array();

		while ($reg=$rspta->fetch_object()) {
			$data[]=array(
            "0"=>($reg->condicion)?'<button class="btn btn-warning btn-xs" onclick="mostrar('.$reg->Id.')"><i class="fa fa-pencil"></i></button>'.' '.'<button class="btn btn-danger btn-xs" onclick="desactivar('.$reg->Id.')"><i class="fa fa-close"></i></button>':'<button class="btn btn-warning btn-xs" onclick="mostrar('.$reg->Id.')"><i class="fa fa-pencil"></i></button>'.' '.'<button class="btn btn-primary btn-xs" onclick="activar('.$reg->Id.')"><i class="fa fa-check"></i></button>',
            "1"=>$reg->detalleentradaequipo,
            "2"=>$reg->descripcion,
            "3"=>$reg->usuario,
            "4"=>$reg->Fecha,
            "5"=>($reg->condicion)?'<span class="label bg-green">Activado</span>':'<span class="label bg-red">Desactivado</span>'
              );
		}
		$results=array(
             "sEcho"=>1,//info para datatables
             "iTotalRecords"=>count($data),//enviamos el total de registros al datatable
             "iTotalDisplayRecords"=>count($data),//enviamos el total de registros a visualizar
             "aaData"=>$data); 
		echo json_encode($results);
		break;




		case 'selectEntradaequipo':
			require_once "../modelos/EntradaEquipo.php";
			$entradaEquipo=new EntradaEquipo();

			$rspta=$entradaEquipo->selectEntradaequipo();

			while ($reg=$rspta->fetch_object()) {
				echo '<option value=0' . $reg->Id.'>'.$reg->Id.'</option>';
			}
			break;



			case 'selectUsuario':
			require_once "../modelos/Entrada.php";
			$entrada=new Entrada();

			$rspta=$entrada->selectUsuario();
			echo '<option value="">Selecciona un Usuario</option>';
			while ($reg=$rspta->fetch_object()) {
				echo '<option value=' . $reg->idusuario.'>'.$reg->nombre.'</option>';
			}
			break;

			case 'selectCosto':
			require_once "../modelos/Avance.php";
			$avance=new Avance();

			$rspta=$avance->selectCosto();

			while ($reg=$rspta->fetch_object()) {
				echo '<input value='.$reg->Costo.'>';
			}
			break;
}
 ?>