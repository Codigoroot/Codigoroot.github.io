<?php 
//redireccionar a la vista de login

header('location: vistas/login_v2.html');
 ?>