<?php 
//activamos almacenamiento en el buffer
ob_start();
session_start();
if (!isset($_SESSION['nombre'])) {
  header("Location: login.html");
}else{

  require 'header.php';
  if ($_SESSION['almacen']==1) {
   ?>
   <div class="content-wrapper">

    <!-- Main content -->
    <section class="content">
      <link rel="stylesheet" type="text/css" href="../public/css/validaciones.css" media="screen" />
      <link rel="stylesheet" type="text/css" href="../public/css/mayusculas.css" media="screen" />
      
      <script language="javascript" src="../public/js/jquery-3.1.1.min.js"></script>

      <script language="javascript">
        $(document).ready(function() {
          $("#IdCliente").change(function() {


            $("#IdCliente option:selected").each(function() {
              id_cliente = $(this).val();
              $.post("../modelos/NumeroCliente.php", {
                id_cliente: id_cliente
              }, function(data) {
                $("#TelefonoCliente").html(data);
              });
            });
          })
        });

        $(document).ready(function() {
          $("#IdCliente").change(function() {


            $("#IdCliente option:selected").each(function() {
              idcliente = $(this).val();
              $.post("../modelos/correoCliente.php", {
                id_cliente: id_cliente
              }, function(data) {
                $("#CorreoCliente").html(data);
              });
            });
          })
        });


        $(document).ready(function() {
          $("#IdMarca").change(function() {


            $("#IdMarca option:selected").each(function() {
              id_marca = $(this).val();
              $.post("../modelos/modeloMarca.php", {
                id_marca: id_marca
              }, function(data) {
                $("#control_modelo").html(data);
              });
            });
          })
        });






      </script>

      <!-- Default box -->
      <div class="row">
        <div class="col-md-12">
          <div class="box">
            <div class="box-header with-border">
              <h1 class="box-title">Equipos <button class="btn btn-success" onclick="mostrarform(true)" id="btnagregar"><i class="fa fa-plus-circle"></i>Ingresar un nuevo equipo</button> </h1>
              <div class="box-tools pull-right">

              </div>
            </div>
            <!--box-header-->
            <!--centro-->
            <div class="panel-body table-responsive" id="listadoregistros">
              <table id="tbllistado" class="table table-striped table-bordered table-condensed table-hover">
                <thead>
                  <th>Opciones</th>
                  <th>ID. Entrada</th>
                  <th>Cliente</th>
                  <th>Articulo</th>
                  <th>Marca</th>
                  <th>Modelo</th>
                  <th>Fecha de Entrada</th>
                  <th>Diagnostico</th>
                  <th>Estado</th>

                </thead>
                <tbody>
                </tbody>
                <tfoot>

                </tfoot>   
              </table>
            </div>


            <div class="panel panel-info">

              <div class="panel-body"  id="formularioregistros">

                <form action="" name="formulario" id="formulario" method="POST">

                  <div class="form-group col-lg-6 col-md-6 col-xs-12">
                    <label for="">Nombre(*):</label>

                    <select name="IdCliente" id="IdCliente" class="form-control selectpicker" data-Live-search="true" required maxlength="30"></select>
                  </div>

                  <div class="form-group col-lg-6 col-md-6 col-xs-12">
                    <label for="">Telefono(*):</label>
                    <select name="TelefonoCliente" id="TelefonoCliente" class="form-control  " data-Live-search="true" ></select>
                  </div>

                  <div class="form-group col-lg-6 col-md-6 col-xs-12">
                    <label for="">Correo(*):</label>
                    <select name="CorreoCliente" id="CorreoCliente" class="form-control " data-Live-search="true" ></select>
                  </div>


                  <div class="form-group col-lg-6 col-md-6 col-xs-12">
                    <label for="">Articulo(*):</label>
                    <select name="IdArticulo" id="IdArticulos" class="form-control selectpicker" data-Live-search="true" required></select>
                  </div>


                  <div class="form-group col-lg-6 col-md-6 col-xs-12">
                    <label for="">Marca(*):</label>
                    <select name="IdMarca" id="IdMarca" class="form-control selectpicker" data-Live-search="true" required><option value="" selected disabled>seleccione la marca</option></select>
                  </div>


                  <div class="form-group col-lg-6 col-md-6 col-xs-12">
                    <label for="">Selecciona un Modelo(*):</label>
                    <select name="control_modelo" id="control_modelo" data-Live-search="true"class="form-control" required=""></select>
                  </div>

                  <div class="form-group col-lg-6 col-md-6 col-xs-12">
                    <label for="">N° Series</label>
                    <input class="form-control" type="hidden" name="Id" id="Id">
                    <input class="form-control" type="text" name="Serie" id="Serie" maxlength="" placeholder="Número de serie" >
                  </div>


                  <div class="form-group col-lg-6 col-md-6 col-xs-12">
                    <label for="">Color</label>
                    <input class="form-control" type="text" name="Color" id="Color" maxlength="15" placeholder="Color del Equipo" required >
                  </div>

                  <div class="form-group col-lg-6 col-md-6 col-xs-12">
                    <label for="">Accesorios</label>
                    <input class="form-control" type="text" name="Accesorios" id="Accesorios" maxlength="100" placeholder="Accesorios Recibidos" style="heigth:300px"  required>
                  </div>


                  <div class="form-group col-lg-6 col-md-6 col-xs-12">
                    <label for="">Diagnostico Tecnico</label>
                    <textarea class="textinput" name="diagnostico" id="diagnostico" rows="3" cols="100"></textarea>
                  </div>


                  <div class="form-group col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <button class="btn btn-primary" type="submit" id="btnGuardar"><i class="fa fa-save"></i>  Guardar</button>

                    <button class="btn btn-danger" onclick="cancelarform()" type="button"><i class="fa fa-arrow-circle-left"></i> Cancelar</button>
                  </div>
                </form>
              </div>
            </div>

            <div class="panel-body" id="tablakardex">
              

                  



                  <div class="panel-body table-responsive" id="listadoregistros1">
                    <table id="tbllistado1" class="table table-striped table-bordered table-condensed table-hover">
                      <thead>
                        <th>ID. Articulo</th>
                        <th>Técnico</th>
                        <th>Proceso realizado</th>
                        <th>Fecha</th>
                       
                      </thead>
                      <tbody>
                      </tbody>
                      <tfoot>

                      </tfoot>   
                    </table>
                  </div>



               
           </div>




           <!--fin centro-->
         </div>
       </div>
     </div>
     <!-- /.box -->

   </section>
   <!-- /.content -->
 </div>
 <?php 




}else{
 require 'noacceso.php'; 
}
require 'footer.php'
?>
<script src="../public/js/JsBarcode.all.min.js"></script>
<script src="../public/js/jquery.PrintArea.js"></script>
<script src="scripts/entradaEquipo.js"></script>
<script src="../public/css/validaciones.css"></script>

<?php 
}


ob_end_flush();
?>