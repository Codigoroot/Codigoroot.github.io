<?php 

//activamos almacenamiento en el buffer
ob_start();
session_start();
if (!isset($_SESSION['nombre'])) {
  header("Location: login.html");
}else{

require 'header.php';
if ($_SESSION['almacen']==1) {
 ?>
    <div class="content-wrapper">
    <!-- Main content -->
    <section class="content">

       <script language="javascript" src="../public/js/jquery-3.1.1.min.js"></script>

        <script language="javascript">
            $(document).ready(function() {
              $("#Id_EntradaEquipo").change(function() {


                    $("#Id_EntradaEquipo option:selected").each(function() {
                        id_entrada = $(this).val();
                        $.post("../modelos/costoEquipo.php", {
                            id_entrada: id_entrada
                        }, function(data) {
                            $("#Monto").html(data);
                        });
                    });
                })
            });

          

</script>





      <!-- Default box -->
      <div class="row">
        <div class="col-md-12">
      <div class="box">
<div class="box-header with-border">
  <h1 class="box-title"> <button class="btn btn-success" onclick="mostrarform(true)" id="btnagregar"><i class="fa fa-plus-circle"></i>Registrar nuevo avance</button> </h1>
  <div class="box-tools pull-right">
    
  </div>
</div>
<!--box-header-->
<!--centro-->
<div class="panel-body table-responsive" id="listadoregistros">
  <table id="tbllistado" class="table table-striped table-bordered table-condensed table-hover">
    <thead>
      <th>Opciones</th>
      <th>ID. Entrada</th>
      <th>Descripcion</th>
      <th>Tecnico que lo realizo</th>
       <th>Fecha de realizacion</th>
    </thead>
    <tbody>
    </tbody>
    <tfoot>
       <th>Opciones</th>
      <th>ID. Entrada</th>
      <th>Descripcion</th>
      <th>Tecnico que lo realizo</th>
      <th>Fecha de realizacion</th>
    </tfoot>   
  </table>
</div>
<div class="panel-body" id="formularioregistros">
  <form action="" name="formulario" id="formulario" method="POST">
   
    
      <div class="form-group col-lg-6 col-md-6 col-xs-12">
      <label for="">ID. de entrada(*):</label>
      <input class="form-control" type="hidden" name="Id" id="Id">
         <select name="Id_EntradaEquipo" id="Id_EntradaEquipo" class="form-control selectpicker" data-Live-search="true" required=""></select> </div>


    <div class="form-group col-lg-6 col-md-6 col-xs-12">
      <label for="">Descripcion</label>
      <input class="form-control" type="text" name="Descripcion" id="Descripcion" maxlength="100" placeholder="Describa detalladamente lo realizado" required>
    </div>

   <div class="form-group col-lg-6 col-md-6 col-xs-12">
      <label for="">Tecnico que realizo el avance</label>
      <select name="Id_usuario" id="Id_usuario" class="form-control selectpicker" data-Live-search="true" required> </select>
    </div>
    
   
    <div class="form-group col-lg-6 col-md-6 col-xs-12">
      <label for="">Fecha</label>
      <input class="form-control" type="date" name="Fecha" id="Fecha" maxlength="6" placeholder="Fecha " required >
    </div>
    <div class="form-group col-lg-6 col-md-6 col-xs-12">
      <label for="">Estado del Equipo</label>
      <select name="Estado" id="Estado" class="form-control selectpicker" data-Live-search="true" required> 
      <option>En Proceso</option> 
      <option>Terminado</option>
      <option>Entregado</option> 

    </select>
    </div>




 <div class="form-group col-lg-3 col-md-3 col-xs-12">
      <label for="">El Monto actual es de $:</label>
         <select name="Monto" id="Monto" class="form-control " data-Live-search="true" required=""></select> </div>


         <div class="form-group col-lg-3 col-md-3 col-xs-12">
      <label for="">Actualizarlo</label>
      <input class="form-control" type="decimal" name="Costo" id="Costo" maxlength="100" placeholder="$0.00" >
    </div>





    <div class="form-group col-lg-12 col-md-12 col-sm-12 col-xs-12">
      <center>
      <button class="btn btn-primary" type="submit" id="btnGuardar"><i class="fa fa-save"></i>  Guardar</button>
      <button class="btn btn-danger" onclick="cancelarform()" type="button"><i class="fa fa-arrow-circle-left"></i> Cancelar</button>
        

         

      </center>
    </div>
    </div>




  </form>
</div>
<!--fin centro-->
      </div>
      </div>
      </div>
      <!-- /.box -->

    </section>
    <!-- /.content -->
  </div>
<?php 
}else{
 require 'noacceso.php'; 
}
require 'footer.php'
 ?>
 <script src="../public/js/JsBarcode.all.min.js"></script>
 <script src="../public/js/jquery.PrintArea.js"></script>
 <script src="scripts/avance.js"></script>

 <?php 
}

ob_end_flush();
  ?>