var tabla;

//funcion que se ejecuta al inicio
function init(){
   mostrarform(false);
   mostrarkardex(false);
   listar();
   
   

   $("#formulario").on("submit",function(e){
    guardaryeditar(e);
   })

  //carhamos los items para seleccionar estado, municipio y colonia
   $.post("../ajax/entradaEquipo.php?op=selectCliente", function(r){
    $("#IdCliente").html(r);
    $("#IdCliente").selectpicker('refresh');
   });
   $("#imagenmuestra").hide();
//cargar telefono de cliente
 /**  $.post("../ajax/entradaEquipo.php?op=selectTelefono", function(r){
    $("#TelefonoCliente").html(r);
    $("#TelefonoCliente").selectpicker('refresh');
   });
   $("#imagenmuestra").hide();
//cargar correo de cliente
    $.post("../ajax/entradaEquipo.php?op=selectCorreo", function(r){
    $("#CorreoCliente").html(r);
    $("#CorreoCliente").selectpicker('refresh');
   });
   $("#imagenmuestra").hide();
*/
//cargar articulo recibido
$.post("../ajax/entradaEquipo.php?op=selectArticulo", function(r){
    $("#IdArticulos").html(r);
    $("#IdArticulos").selectpicker('refresh');
});
$("#imagenmuestra").hide();

   //cargar marca del articulo
   $.post("../ajax/entradaEquipo.php?op=selectMarca", function(r){
    $("#IdMarca").html(r);
    $("#IdMarca").selectpicker('refresh');
   });
   $("#imagenmuestra").hide();

 //cargar modelo del articulo
  /* $.post("../ajax/entradaEquipo.php?op=selectModelo", function(r){
    $("#IdModelo").html(r);
    $("#IdModelo").selectpicker('refresh');
   });
   $("#imagenmuestra").hide();

   */
   //cargar modelo del articulo
   $.post("../ajax/entradaEquipo.php?op=selectUsuario", function(r){
    $("#Recibio").html(r);
    $("#Recibio").selectpicker('refresh');
   });
   $("#imagenmuestra").hide();
   

}





//funcion limpiar
function limpiar(){
    $("#Id").val("");
    $("#IdCliente").val("");
    $("#TelefonoCliente").val("");
    $("#CorreoCliente").val("");
    $("#IdArticulo").attr("src","");
    $("#IdMarca").val("");
    $("#IdModelo").hide();
    $("#Color").val("");
    $("#Serie").val("");
    $("#Accesorios").val("");
    $("#diagnostico").val("");

}

//funcion mostrar formulario
function mostrarform(flag){
    limpiar();
    if(flag){
        $("#listadoregistros").hide();
        $("#formularioregistros").show();
        $("#btnGuardar").prop("disabled",false);
        $("#btnagregar").hide();
    }else{
        $("#listadoregistros").show();
        $("#formularioregistros").hide();
        $("#btnagregar").show();
    }
}




function mostrarkardex(flag){
    
    if(flag){
        $("#listadoregistros").hide();
        $("#formularioregistros").hide();
        $("#tablakardex").show();
        $("#btnGuardar").prop("disabled",false);
        $("#btnagregar").hide();
    }else{
        $("#listadoregistros").show();
        $("#formularioregistros").hide();
        $("#tablakardex").hide();
        $("#btnagregar").show();
    }
}

//cancelar form
function cancelarform(){
    limpiar();
    mostrarform(false);
    mostrarkardex(false);
}

//funcion listar
function listar(){
    tabla=$('#tbllistado').dataTable({
        "aProcessing": true,//activamos el procedimiento del datatable
        "aServerSide": true,//paginacion y filrado realizados por el server
        dom: 'Bfrtip',//definimos los elementos del control de la tabla
        buttons: [
                  
        ],
        "ajax":
        {
            url:'../ajax/entradaEquipo.php?op=listar',
            type: "get",
            dataType : "json",
            error:function(e){
                console.log(e.responseText);
            }
        },
        "bDestroy":true,
        "iDisplayLength":8,//paginacion
        "order":[[0,"asc"]]//ordenar (columna, orden)
    }).DataTable();
}




function listar1(Id){
  mostrarkardex(true);
    tabla=$('#tbllistado1').dataTable({
        "aProcessing": true,//activamos el procedimiento del datatable
        "aServerSide": true,//paginacion y filrado realizados por el server
        dom: 'Bfrtip',//definimos los elementos del control de la tabla
        buttons: [
                  
        ],
        "ajax":
        {
            url:'../ajax/entradaEquipo.php?op=kardex1',
            data:{Id:Id},
            type: "POST",
            dataType : "json",
            error:function(e){
                console.log(e.responseText);
            }
        },
        "bDestroy":true,
        "iDisplayLength":8,//paginacion
        "order":[[0,"asc"]]//ordenar (columna, orden)
    }).DataTable();
}
//funcion para guardaryeditar
function guardaryeditar(e){
     e.preventDefault();//no se activara la accion predeterminada 
     $("#btnGuardar").prop("disabled",true);
     var formData=new FormData($("#formulario")[0]);

     $.ajax({
        url: "../ajax/entradaEquipo.php?op=guardaryeditar",
        type: "POST",
        data: formData,
        contentType: false,
        processData: false,

        success: function(datos){
            bootbox.alert(datos);
            mostrarform(false);
            mostrarkardex(false);
            limpiar();
            tabla.ajax.reload();
        }
     });

     limpiar();
}

function mostrar(Id){

    $.post("../ajax/entradaEquipo.php?op=mostrar",{Id : Id},
        function(data,status)
        {
            data=JSON.parse(data);
            mostrarform(true);

            
                $("#Id").val(data.Id);
            $("#IdCliente").val(data.Nombre);
                
            $("#Color").val(data.Color);
            $("#Serie").val(data.Serie);
            $("#fechaRecepcion").val(data.fechaRecepcion);
            $("#Accesorios").val(data.Accesorios);
            $("#diagnostico").val(data.diagnostico);
            
            
        })
}

function kardex(Id){
    $.post("../ajax/entradaEquipo.php?op=kardex1",{Id : Id},
        function(data,status)
        {
            data=JSON.parse(data);
            mostrarkardex(false);

            
    
            
            
        })
}


//funcion para desactivar
function desactivar(Id){
    bootbox.confirm("¿Esta seguro de desactivar este dato?", function(result){
        if (result) {
            $.post("../ajax/entradaEquipo.php?op=desactivar", {Id : Id}, function(e){
                bootbox.alert(e);
                tabla.ajax.reload();
            });
        }
    })
}

function activar(Id){
    bootbox.confirm("¿Esta seguro de activar este dato?" , function(result){
        if (result) {
            $.post("../ajax/entradaEquipo.php?op=activar" , {Id : Id}, function(e){
                bootbox.alert(e);
                tabla.ajax.reload();
            });
        }
    })
}




init();