<?php
//activamos almacenamiento en el buffer
ob_start();
session_start();
if (!isset($_SESSION['nombre'])) {
  header("Location: login.html");
}else{

 
require 'header.php';

if ($_SESSION['Internet']==1) {

 


 ?>
    <div class="content-wrapper">
    <!-- Main content -->
    <section class="content">

      <!-- Default box -->
      <div class="row">
        <div class="col-md-12">
      <div class="box">
<div class="box-header with-border">
  <h1 class="box-title">Registro de Numero de Control</h1>
  <div class="box-tools pull-right">
    
  </div>
</div>

<div class="box-header with-border">
  <h1 class="box-title">Ultimos Números de control</h1>
  <br>
  <label for="">B/N  </label>  <?php echo ucwords($_SESSION['nombre']); ?>
  <br>
  <label for="">Copia </label> <?php echo ucwords($_SESSION['nombre']); ?>
  <br>
  <label for="">A/C</label>  <?php echo ucwords($_SESSION['nombre']); ?>
  <br>
  <label for="">Escan </label>  <?php echo ucwords($_SESSION['nombre']); ?>
  <div class="box-tools pull-right">
    
  </div>
</div>


<!--box-header-->
<!--centro-->
<div class="panel-body">
 

<div class="panel-body" id="formularioregistros">
  <form action="" name="formulario" id="formulario" method="POST">
    <div class="form-group col-lg-3 col-md-6 col-xs-12">
      <label for="">Numero de Control B/N</label>
      <input class="form-control" type="hidden" name="IdMarca" id="IdMarca">
      <input class="form-control" type="number" name="Nombre" id="Nombre" maxlength="100" placeholder="Control B/N" required>
    </div>
    
    
    <div class="form-group col-lg-3 col-md-6 col-xs-12">
      <label for="">Numero de Control Copia</label>
      <input class="form-control" type="hidden" name="IdMarca" id="IdMarca">
      <input class="form-control" type="number" name="Nombre" id="Nombre" maxlength="100" placeholder="Control Copia" required>
    </div>

    <div class="form-group col-lg-3 col-md-6 col-xs-12">
      <label for="">Numero de Control A/C</label>
      <input class="form-control" type="hidden" name="IdMarca" id="IdMarca">
      <input class="form-control" type="number" name="Nombre" id="Nombre" maxlength="100" placeholder="Control A/C" required>
    </div>

    <div class="form-group col-lg-3 col-md-6 col-xs-12">
      <label for="">Numero de Control Escan</label>
      <input class="form-control" type="hidden" name="IdMarca" id="IdMarca">
      <input class="form-control" type="number" name="Nombre" id="Nombre" maxlength="100" placeholder="Control Escan" required>
    </div>


   <div class="form-group col-lg-12 col-md-12 col-sm-12 col-xs-12">  
      <button class="btn btn-primary" type="submit" id="btnGuardar"></i>Registrar y actualizar</button>

 <!--        <button class="btn btn-danger" onclick="cancelarform()" type="button"><i class="fa fa-arrow-circle-left"></i> Cancelar</button> -->
    </div>  
  </form>
</div>
       
   

</div>
</div>
</div>
</div>


    

  </div>





<?php 
}else{
 require 'noacceso.php'; 
}

require 'footer.php';
 ?>


 <?php 
}

ob_end_flush();
  ?>

