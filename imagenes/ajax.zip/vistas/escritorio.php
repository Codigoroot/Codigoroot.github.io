<?php
//activamos almacenamiento en el buffer
ob_start();
session_start();
if (!isset($_SESSION['nombre'])) {
  header("Location: login_v2.html");
}else{

 
  require 'header.php';

  if ($_SESSION['escritorio']==1) {

    require_once "../modelos/Consultas.php";
    $consulta = new Consultas();
    $rsptac = $consulta->totalrecibidos();
    $regc=$rsptac->fetch_object();
    $totalRe=$regc->totalR;


    $rsptac = $consulta->totalProceso();
    $regc=$rsptac->fetch_object();
    $totalEPr=$regc->totalEP;


    $rsptac = $consulta->totalEntregados();
    $regc=$rsptac->fetch_object();
    $totalEn=$regc->totalE;

    $rsptac = $consulta->totalTerminados();
    $regc=$rsptac->fetch_object();
    $totalTe=$regc->totalT;


    
    


    ?>
    <div class="content-wrapper">
      <!-- Main content -->
      <section class="content">

        <!-- Default box -->
        <div class="row">
          <div class="col-md-12">
            <div class="box">
              <div class="box-header with-border">
                <h1 class="box-title">Inicio</h1>
                <div class="box-tools pull-right">
                  
                </div>
              </div>



              <!--box-header-->
              <!--centro-->
              <div class="panel-body">
               

                <div class="col-12 col-sm-6 col-md-6">
                  <div class="info-box">
                    <span class="info-box-icon bg-red"><i class="fa fa-window-close-o" aria-hidden="true"></i></span>
                    <div class="info-box-content">
                      <div class="inner">
                        <CENTER>
                          <h3 style="font-size: 10px;">
                            SIN REVISAR

                          </h3>

                          <h1 style="font-size: 25px;">
                            <strong> <?php echo  "" . $totalRe ; ?> </strong>
                          </h1>
                        </CENTER>

                      </div>
                    </div>
                  </div>
                </div>



                <div class="col-12 col-sm-6 col-md-6">
                  <div class="info-box">
                    <span class="info-box-icon bg-yellow"><i class="fa fa-cog fa-spin fa-1x fa-fw"></i></span>
                    <div class="info-box-content">
                      <div class="inner">
                        <CENTER>
                          <h3 style="font-size: 10px;">
                            EN REVISIÓN

                          </h3>

                          <h1 style="font-size: 25px;">
                            <strong> <?php echo  "" . $totalEPr ; ?> </strong>
                          </h1>
                        </CENTER>

                      </div>
                    </div>
                  </div>
                </div>



                <br>
                <br>
                <br>
                <br>


                <div class="col-12 col-sm-6 col-md-6 ">
                  <div class="info-box">
                    <span class="info-box-icon bg-blue"><i class="fa fa-check-square-o"></i></span>
                    <div class="info-box-content">
                      <div class="inner">
                        <CENTER>
                          <h3 style="font-size: 10px;">
                            TERMINADOS
                          </h3>

                          <h1 style="font-size: 25px;">
                            <strong> <?php echo  "" . $totalTe ; ?> </strong>
                          </h1>
                        </CENTER>

                      </div>
                    </div>
                  </div>
                </div>




                <div class="col-12 col-sm-6 col-md-6">
                  <div class="info-box">
                    <span class="info-box-icon bg-green"><i class="fa fa-check" aria-hidden="true"></i></span>
                    <div class="info-box-content">
                      <div class="inner">
                        <CENTER>
                          <h3 style="font-size: 10px;">
                            ENTREGADOS
                          </h3>

                          <h1 style="font-size: 25px;">
                            <strong> <?php echo  "" . $totalEn ; ?> </strong>
                          </h1>
                        </CENTER>

                      </div>
                    </div>
                  </div>
                </div>




              </div>
            </div>
          </div>
        </div>



        <div class="row">
          <div class="col-md-12">
            <div class="box">
              <div class="box-header with-border">
                <center><h1 class="box-title">Equipos Recibidos</h1></center>
                <div class="box-tools pull-right">
                  
                </div>
              </div>

              <!--box-header-->
              <!--centro-->
              <div class="panel-body">

                <div class="col-lg-3 col-sm-6 col-md-3 ">
                  <div class="info-box">
                    <span class="info-box-icon bg-blue"><i class="fa fa-laptop"></i></span>
                    <div class="info-box-content">
                      <div class="inner">
                        <CENTER>
                          <h3 style="font-size: 15px;">
                            Laptop
                          </h3>

                          <h1 style="font-size: 20px;">
                            <strong> <?php echo  "" . $totalTe ; ?> </strong>
                          </h1>
                        </CENTER>

                      </div>
                    </div>
                  </div>
                </div>

                
                <div class="col-lg-3 col-sm-6 col-md-3">
                  <div class="info-box">
                    <span class="info-box-icon bg-green"><i class="fa fa-print" aria-hidden="true"></i></span>
                    <div class="info-box-content">
                      <div class="inner">
                        <CENTER>
                          <h3 style="font-size: 15px;">
                            Impresoras
                          </h3>

                          <h1 style="font-size: 20px;">
                            <strong> <?php echo  "" . $totalEn ; ?> </strong>
                          </h1>
                        </CENTER>

                      </div>
                    </div>
                  </div>
                </div>

                
                <div class="col-lg-3 col-sm-6 col-md-3">
                  <div class="info-box">
                    <span class="info-box-icon bg-green"><i class="fa fa-desktop" aria-hidden="true"></i></span>
                    <div class="info-box-content">
                      <div class="inner">
                        <CENTER>
                          <h3 style="font-size: 15px;">
                            Escritorio
                          </h3>

                          <h1 style="font-size: 20px;">
                            <strong> <?php echo  "" . $totalEn ; ?> </strong>
                          </h1>
                        </CENTER>

                      </div>
                    </div>
                  </div>
                </div>



                <div class="col-lg-3 col-sm-6 col-md-3 ">
                  <div class="info-box">
                    <span class="info-box-icon bg-blue"><i class="fa fa-laptop"></i></span>
                    <div class="info-box-content">
                      <div class="inner">
                        <CENTER>
                          <h3 style="font-size: 15px;">
                            All in One
                          </h3>

                          <h1 style="font-size: 20px;">
                            <strong> <?php echo  "" . $totalTe ; ?> </strong>
                          </h1>
                        </CENTER>

                      </div>
                    </div>
                  </div>
                </div>






                
                

              </div>
            </div>
          </div>
        </div>


        <!-- /.box -->

      </section>
      <!-- /.content -->
    </div>
    <?php 
  }else{
   require 'noacceso.php'; 
 }

 require 'footer.php';
 ?>


 <?php 
}

ob_end_flush();
?>

