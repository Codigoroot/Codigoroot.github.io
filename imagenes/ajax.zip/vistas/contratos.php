<?php
//activamos almacenamiento en el buffer
ob_start();
session_start();
if (!isset($_SESSION['nombre'])) {
  header("Location: login_v2.html");
}else{

 


if ($_SESSION['Internet']==1) {

 


 ?>
<!DOCTYPE html>
<!--[if IE 8]> <html lang="en" class="ie8"> <![endif]-->
<!--[if !IE]><!-->
<html lang="en">
<!--<![endif]-->
<head>
  <meta charset="utf-8" />
  <title>Inovatec | Internet</title>
  <meta content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" name="viewport" />
  <meta content="" name="description" />
  <meta content="" name="author" />
  
  <!-- ================== BEGIN BASE CSS STYLE ================== -->
  <link href="http://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700" rel="stylesheet">
  <link href="assets/plugins/jquery-ui/themes/base/minified/jquery-ui.min.css" rel="stylesheet" />
  <link href="assets/plugins/bootstrap/css/bootstrap.min.css" rel="stylesheet" />
  <link href="assets/plugins/font-awesome/css/font-awesome.min.css" rel="stylesheet" />
  <link href="assets/css/animate.min.css" rel="stylesheet" />
  <link href="assets/css/style.min.css" rel="stylesheet" />
  <link href="assets/css/style-responsive.min.css" rel="stylesheet" />
  <link href="assets/css/theme/default.css" rel="stylesheet" id="theme" />
  <!-- ================== END BASE CSS STYLE ================== -->
  
  <!-- ================== BEGIN PAGE LEVEL STYLE ================== -->
  <link href="assets/plugins/bootstrap-wizard/css/bwizard.min.css" rel="stylesheet" />
  <!-- ================== END PAGE LEVEL STYLE ================== -->
  
  <!-- ================== BEGIN BASE JS ================== -->
  <script src="assets/plugins/pace/pace.min.js"></script>
  <!-- ================== END BASE JS ================== -->
</head>
<body>
  <!-- begin #page-loader -->
  <div id="page-loader" class="fade in"><span class="spinner"></span></div>
  <!-- end #page-loader -->
  
  <!-- begin #page-container -->
  <div id="page-container" class="fade page-sidebar-fixed page-header-fixed">
    <!-- begin #header -->
    <div id="header" class="header navbar navbar-default navbar-fixed-top">
      <!-- begin container-fluid -->
      <div class="container-fluid">
        <!-- begin mobile sidebar expand / collapse button -->
        <div class="navbar-header">
          <a href="" class="navbar-brand"><span class="navbar-logo"></span> INOVATEC </a>
          <button type="button" class="navbar-toggle" data-click="sidebar-toggled">
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
        </div>
        <!-- end mobile sidebar expand / collapse button -->
        
        <!-- begin header navigation right -->
        <ul class="nav navbar-nav navbar-right">
          <li>
            <form class="navbar-form full-width">
              <div class="form-group">
                <input type="text" class="form-control" placeholder="Código de mantenimiento" />
                <button type="submit" class="btn btn-search"><i class="fa fa-search"></i></button>
              </div>
            </form>
          </li>
         
          <li class="dropdown navbar-user">
            <a href="javascript:;" class="dropdown-toggle" data-toggle="dropdown">
              <img src="assets/img/IMI_Logo.png" alt="" /> 
              <span class="hidden-xs"><b> <?php echo ucwords($_SESSION['nombre']); ?> <?php echo ucwords($_SESSION['tipo_documento']); ?> <?php echo ucwords($_SESSION['num_documento']); ?></b> </span> <b class="caret"></b>
            </a>
            <ul class="dropdown-menu animated fadeInLeft">
              <li class="arrow"></li>
             <!-- <li><a href="javascript:;">Edit Profile</a></li>
              <li><a href="javascript:;"><span class="badge badge-danger pull-right">2</span> Inbox</a></li>
              <li><a href="javascript:;">Calendar</a></li>
              <li><a href="javascript:;">Setting</a></li>
              <li class="divider"></li>
               -->
              <li><a href="../ajax/usuario.php?op=salir">Cerrar Sesión</a></li>
            </ul>
          </li>
        </ul>
        <!-- end header navigation right -->
      </div>
      <!-- end container-fluid -->
    </div>
    <!-- end #header -->
    
    <!-- begin #sidebar -->
    <div id="sidebar" class="sidebar">
      <!-- begin sidebar scrollbar -->
      <div data-scrollbar="true" data-height="100%">
        <!-- begin sidebar user -->
        <ul class="nav">
          <li class="nav-profile">
            <div class="image">
              <a href="javascript:;"><img src="assets/img/IMI_Logo.png" alt="" /></a>
            </div>
            <div class="info">
             <span class="hidden-xs"><b> <?php echo ucwords($_SESSION['nombre']); ?> <?php echo ucwords($_SESSION['tipo_documento']); ?> <?php echo ucwords($_SESSION['num_documento']); ?></b> </span>
              <small>Admin</small>
            </div>
          </li>
        </ul>
        <!-- end sidebar user -->
        <!-- begin sidebar nav -->
        <ul class="nav">
         
          <li class="has-sub">
            <a href="javascript:;">
                <a href="escritorio.php"><i class="fa fa-laptop"></i>
                <span>Inicio</span>
              </a>
            
          </li>
        
          <li class="has-sub">
            <a href="javascript:;">
                <b class="caret pull-right"></b>
                <i class="fa fa-suitcase"></i>
                <span>Clientes</span> 
            </a>
            <ul class="sub-menu">
              <li><a href="clientes.php">Administrar Clientes</a></li>
            </ul>
          </li>
          <li class="has-sub">
            <a href="javascript:;">
                <b class="caret pull-right"></b>
                <i class="fa fa-file-o"></i>
                <span>Administrar Equipos </span> 
            </a>
            <ul class="sub-menu">
              <li><a href="articulo.php">Articulos</a></li>
              <li><a href="marca.php">Marcas </a></li>
              <li><a href="modelo.php">Modelos</a></li>
            </ul>
          </li>
          <li class="has-sub">
            <a href="javascript:;">
                <b class="caret pull-right"></b>
                <i class="fa fa-th"></i>
                <span>Entrada Equipos</span>
            </a>
            <ul class="sub-menu">
              <li><a href="entradaEquipo.php">Nuevo Equipo</a></li>
            </ul>
          </li>
          <li class="has-sub">
            <a href="javascript:;">
                <b class="caret pull-right"></b>
              <i class="fa fa-star"></i> 
              <span>Avances</span>
            </a>
            <ul class="sub-menu">
                <li><a href="avance.php" target="_blank">Agregar Avance</a></li>
            </ul>
          </li>
          <li class="has-sub">
              <a href="javascript:;">
                <b class="caret pull-right"></b>
                  <i class="fa fa-envelope"></i>
                  <span>Reportes</span>
              </a>
            <ul class="sub-menu">
              <li><a href="reportesporfecha.php">Reportes por fecha</a></li>
              <li><a href="reportesMarca.php">Reportes por marca</a></li>
            </ul>
          </li>
          <li class="has-sub">
              <a href="javascript:;">
                <b class="caret pull-right"></b>
                  <i class="fa fa-users"></i>
                <span>Usuarios</span>
            </a>
            <ul class="sub-menu">
                <li><a href="usuario.php">Administrar usuarios</a></li>
            </ul>
          </li>
          
          <li class="has-sub">
              <a href="reportes.php">
                  
                  <i class="fa fa-file-text"></i>
                  <span>reportes de Impresión</span>
              </a>
          </li>
          <li class="has-sub">
              <a href="contratos.php">
                
                <i class="fa fa-file-text"></i>
                <span>Contratos de Internet</span>
            </a>
          </li>
          
              <!-- begin sidebar minify button -->
          <li><a href="javascript:;" class="sidebar-minify-btn" data-click="sidebar-minify"><i class="fa fa-angle-double-left"></i></a></li>
              <!-- end sidebar minify button -->
        </ul>
        <!-- end sidebar nav -->
      </div>
      <!-- end sidebar scrollbar -->
    </div>
    <div class="sidebar-bg"></div>
    <!-- end #sidebar -->
    
    <!-- begin #content -->
    <div id="content" class="content">
      <!-- begin breadcrumb -->
      <ol class="breadcrumb pull-right">
        <li><a href="escritorio.php">Inicio</a></li>
        <li><a href="javascript:;">Internet</a></li>
        <li class="active">Crear Contrato</li>
      </ol>
      <!-- end breadcrumb -->
      <!-- begin page-header -->
      <h1 class="page-header"><small>Ingrese los datos correctos para hacer un nuevo contrato</small></h1>
      <!-- end page-header -->
      
      <!-- begin row -->
      <div class="row">
                <!-- begin col-12 -->
          <div class="col-md-12">
              <!-- begin panel -->
                    <div class="panel panel-inverse">
                        <div class="panel-heading">
                            <div class="panel-heading-btn">
                                <a href="javascript:;" class="btn btn-xs btn-icon btn-circle btn-default" data-click="panel-expand"><i class="fa fa-expand"></i></a>
                                <a href="javascript:;" class="btn btn-xs btn-icon btn-circle btn-success" data-click="panel-reload"><i class="fa fa-repeat"></i></a>
                                <a href="javascript:;" class="btn btn-xs btn-icon btn-circle btn-warning" data-click="panel-collapse"><i class="fa fa-minus"></i></a>
                                <a href="javascript:;" class="btn btn-xs btn-icon btn-circle btn-danger" data-click="panel-remove"><i class="fa fa-times"></i></a>
                            </div>
                            <h4 class="panel-title">Contrato nuevo</h4>
                        </div>
                        <div class="panel-body">
                            <form action="" name="form_contratos" id="form_contratos" method="POST">
                <div id="wizard">
                  <ol>
                    <li>
                       Datos personales
                        <small>Registre los datos personales del titular del contrato.</small>
                    </li>
                    <li>
                        Paquete de Internet
                        <small>Especifique los datos del paquete contratado asi como la forma de pago</small>
                    </li>
                    <li>
                        Ubicación
                        <small>Ingrese la ubicacion donde se instalara el servicio de internet</small>
                    </li>
                    <li>
                        Verificacion
                        <small>Verifique y confirme los datos</small>
                    </li>
                  </ol>
              
<div id="step-1">

<fieldset>

      <legend class="pull-left width-full">Datos Personales del titular del contrato</legend> 
      <!-- begin row --> 
      <div class="row"> 
        <!-- begin col-4 -->
        <div class="col-md-4"> 
          <div class="form-group"> 
            <label>Nombre y Apellidos</label> 
            <div class="controls"> 
              <input type="text" name="username"   placeholder="Nombre" class="form-control" /> 
            </div>
          </div>
        </div> 
      <!-- end col-4 --> <!-- begin col-4 --> 
        <div class="col-md-4"> 
          <div class="form-group"> 
            <label>Telefono 1</label> 
            <div class="controls"> 
              <input type="number" id="telefono1" maxlength="10" name="username" placeholder="(###)-###-##-##" class="form-control"  /> 
            </div>
          </div>
        </div> 
       <!-- end col-4 --> <!-- begin col-4 -->
        <div class="col-md-4"> 
          <div class="form-group"> 
            <label>Telefono 2</label> 
            <div class="controls"> 
              <input type="number" id="telefono2" name="username" placeholder="(###)-###-##-##" class="form-control"  /> 
            </div>
          </div>
        </div> 
      <!-- end col-6 --> 

      <div class="col-md-4"> 
          <div class="form-group"> 
            <label>Correo Electronico</label> 
            <div class="controls"> 
              <input type="email" name="username" placeholder="Nombre" class="form-control"  /> 
            </div>
          </div>
        </div> 
           <!-- end col-6 --> 
      </div> <!--
    end row --> 
  </fieldset>

</div>
                  <!-- end wizard step-1 -->
                  <!-- begin wizard step-2 -->
                  <div>
                    <fieldset>
                      <legend class="pull-left width-full">Datos del Servicio</legend>
                                            <!-- begin row -->
        <div class="form-group row m-b-10">
              <div class="col-lg-9 col-xl-6">
                  <div class="row row-space-6">
                   
                    <div class="col-md-8"> 
                      <div class="form-group  col-lg-6 col-md-10 col-xs-12">
                        <label for="">Paquete contratado:</label>
                          <select name="control_paquete" id="control_paquete"data-Live-search="true"class="form-control" required="">
                                <option value="value1" selected>Selecciones un paquete</option> 
                                <option value="value2" >2 MB</option>
                                <option value="value3">3 MB</option>
                                <option value="value2" >4 MB</option>
                                <option value="value3">6 MB</option>
                          </select>
                        </div>
                          <div class="col-md-10">
                            <div class="form-group">
                              <label>Descripcion del contrato</label>
                              <div class="controls">
                                <div>
                        <textarea id="console" rows="8" class="form-control"></textarea>
                    </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                                            <!-- end row -->
                    </fieldset>
                  </div>
                  <!-- end wizard step-2 -->
                  <!-- begin wizard step-3 -->
                  <div>
                    <fieldset>
                      <legend class="pull-left width-full">Ubicacion del domicilio</legend>
                                            <!-- begin row -->
                                            <div class="row">
                                                <!-- begin col-4 -->
                                                <div class="col-md-3">
                                                    <div class="form-group">
                                                        <label>Calle</label>
                                                        <div class="controls">
                                                            <input type="text" name="username" placeholder="Calle" class="form-control" />
                                                        </div>
                                                    </div>
                                                </div>
                                                <!-- end col-4 -->
                                                <!-- begin col-4 -->
                                                <div class="col-md-3">
                                                    <div class="form-group">
                                                        <label>Numero Exterior</label>
                                                        <div class="controls">
                                                            <input type="number" name="#numero" placeholder="Num. Ext." class="form-control" />
                                                        </div>
                                                    </div>
                                                </div>
                                                <!-- end col-4 -->
                                                <!-- begin col-4 -->
                                                <div class="col-md-3">
                                                    <div class="form-group">
                                                        <label>Numero Interior</label>
                                                        <div class="controls">
                                                            <input type="text" name="password2" placeholder="Num. Int." class="form-control" />
                                                        </div>
                                                    </div>
                                                </div>

                                                <div class="col-md-3">
                                                    <div class="form-group">
                                                        <label>Edificio</label>
                                                        <div class="controls">
                                                            <input type="text" name="password2" placeholder="" class="form-control" />
                                                        </div>
                                                    </div>
                                                </div>

                                                <div class="col-md-3">
                                                    <div class="form-group">
                                                        <label>Departamento</label>
                                                        <div class="controls">
                                                            <input type="text" name="password2" placeholder="" class="form-control" />
                                                        </div>
                                                    </div>
                                                </div>

                                                <div class="col-md-3">
                                                    <div class="form-group">
                                                        <label>Manzana</label>
                                                        <div class="controls">
                                                            <input type="text" name="password2" placeholder="" class="form-control" />
                                                        </div>
                                                    </div>
                                                </div>

                                                <div class="col-md-3">
                                                    <div class="form-group">
                                                        <label>Lote</label>
                                                        <div class="controls">
                                                            <input type="text" name="password2" placeholder="" class="form-control" />
                                                        </div>
                                                    </div>
                                                </div>

                                                <div class="col-md-3">
                                                    <div class="form-group">
                                                        <label>Colonia</label>
                                                        <div class="controls">
                                                            <input type="text" name="password2" placeholder="" class="form-control" />
                                                        </div>
                                                    </div>
                                                </div>

                                                <div class="col-md-3">
                                                    <div class="form-group">
                                                        <label>C.P.</label>
                                                        <div class="controls">
                                                            <input type="text" name="password2" placeholder="" class="form-control" />
                                                        </div>
                                                    </div>
                                                </div>

                                                <div class="col-md-3">
                                                    <div class="form-group">
                                                        <label>Delegacion</label>
                                                        <div class="controls">
                                                            <input type="text" name="password2" placeholder="" class="form-control" />
                                                        </div>
                                                    </div>
                                                </div>

                                                <div class="col-md-3">
                                                    <div class="form-group">
                                                        <label>Ciudad</label>
                                                        <div class="controls">
                                                            <input type="text" name="password2" placeholder="" class="form-control" />
                                                        </div>
                                                    </div>
                                                </div>

                                                <div class="col-md-3">
                                                    <div class="form-group">
                                                        <label>Municipio</label>
                                                        <div class="controls">
                                                            <input type="text" name="password2" placeholder="" class="form-control" />
                                                        </div>
                                                    </div>
                                                </div>

                                                <div class="col-md-3">
                                                    <div class="form-group">
                                                        <label>Estado</label>
                                                        <div class="controls">
                                                            <input type="text" name="password2" placeholder="" class="form-control" />
                                                        </div>
                                                    </div>
                                                </div>

                                                <div class="col-md-3">
                                                    <div class="form-group">
                                                        <label>Entre calle 1</label>
                                                        <div class="controls">
                                                            <input type="text" name="password2" placeholder="" class="form-control" />
                                                        </div>
                                                    </div>
                                                </div>

                                                <div class="col-md-3">
                                                    <div class="form-group">
                                                        <label>Entre calle 2</label>
                                                        <div class="controls">
                                                            <input type="text" name="password2" placeholder="" class="form-control" />
                                                        </div>
                                                    </div>
                                                </div>

                                                <div class="col-md-3">
                                                    <div class="form-group">
                                                      <label >Referencias del domicilio</label>
                                                        <textarea id="casa" rows="8" class="form-control"></textarea>
                                                        
                                                    </div>
                                                </div>
                                                <!-- end col-6 -->
                                            </div>
                                            <!-- end row -->
                                        </fieldset>
                  </div>
                  <!-- end wizard step-3 -->
                  <!-- begin wizard step-4 -->
                  <div>
                      
                                            <h1>Confirme los datos</h1>
                                          
              
              <div class="table-responsive">
                        <table id="user" class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                    <th>Concepto</th>
                                    <th>Valor</th>
                                    
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>Nombre Completo</td>
                                    <td><a href="#" id="username" data-type="text" data-pk="1" data-title="Enter Username">Javier Aguilar Dominguez </a>
                                    </td> 
                                    
                                </tr>
                                <tr>
                                    <td>Numero telefonico 1</td>
                                    <td><a href = "#" id = "comments" data-type = "text" data-pk = "1"> 231 108 95 56 </a></td>
                                    
                                </tr>
                                <tr>
                                    <td>Numero telefonico 2</td>
                                    <td><a href = "#" id = "commentss" data-type = "text" data-pk = "5"> 231 108 95 56 </a></td>
                                    
                                </tr>
                                <tr>
                                    <td>Correo Electronico</td>
                                    <td><a href = "#" id = "comments" data-type = "text" data-pk = "1"> rootcodigo@gmail.com </a></td>
                                </tr>
                                <tr>
                                    <td>Paquete Contratado</td>
                                    <td><a href="#" id="group" data-type="select" data-pk="1" data-value="5" data-source="/groups" data-title="Seleccionar Paquete">2 MB</a></td>
                                     
                                </tr>
                                
                                <tr>
                                    <td>Observaciones del contrato</td>
                                    <td><a href="#" id="username" data-type="text" data-pk="1" data-title="Enter Username">Contrato diferido a dos Meses</a></td>
                                   
                                </tr>
                                
                                
                                <tr>
                                    <td>Domicilio</td>
                                    <td><a href="#" id="username" data-type="text" data-pk="1" data-title="Enter Username">Guadalupe Victora S/N privada principal </a></td>
                                    
                                </tr>

                                <tr>
                                    <td>Referencia del domicilio</td>
                                    <td>
                                        <a href="#" id="comments" data-type="textarea" data-pk="1" data-placeholder="Your comments here..." data-original-title="Enter comments">El domicilio se encuentra Ubicado atras de la unidad habitacional</a></td>
                                </tr>
                                
                                
                             
                            </tbody>
                        </table>
                    </div>
                    
         
                                            
                                          <center>  <button class="btn btn-success btn-lg" type="submit" id="btnGuardar"><i class="fa fa-save"></i> Crear Contrato</button>
                                        </center>
                  </div>
                  <!-- end wizard step-4 -->
                </div>
              </form>
                        </div>
                    </div>
                    <!-- end panel -->
                </div>
                <!-- end col-12 -->
            </div>
            <!-- end row -->
    </div>
    <!-- end #content -->
    
    
    
        <!--  
        <div class="theme-panel">
            <a href="javascript:;" data-click="theme-panel-expand" class="theme-collapse-btn"><i class="fa fa-cog"></i></a>
            <div class="theme-panel-content">
                <h5 class="m-t-0">Color Theme</h5>
                <ul class="theme-list clearfix">
                    <li class="active"><a href="javascript:;" class="bg-green" data-theme="default" data-click="theme-selector" data-toggle="tooltip" data-trigger="hover" data-container="body" data-title="Default">&nbsp;</a></li>
                    <li><a href="javascript:;" class="bg-red" data-theme="red" data-click="theme-selector" data-toggle="tooltip" data-trigger="hover" data-container="body" data-title="Red">&nbsp;</a></li>
                    <li><a href="javascript:;" class="bg-blue" data-theme="blue" data-click="theme-selector" data-toggle="tooltip" data-trigger="hover" data-container="body" data-title="Blue">&nbsp;</a></li>
                    <li><a href="javascript:;" class="bg-purple" data-theme="purple" data-click="theme-selector" data-toggle="tooltip" data-trigger="hover" data-container="body" data-title="Purple">&nbsp;</a></li>
                    <li><a href="javascript:;" class="bg-orange" data-theme="orange" data-click="theme-selector" data-toggle="tooltip" data-trigger="hover" data-container="body" data-title="Orange">&nbsp;</a></li>
                    <li><a href="javascript:;" class="bg-black" data-theme="black" data-click="theme-selector" data-toggle="tooltip" data-trigger="hover" data-container="body" data-title="Black">&nbsp;</a></li>
                </ul>
                <div class="divider"></div>
                <div class="row m-t-10">
                    <div class="col-md-5 control-label double-line">Header Styling</div>
                    <div class="col-md-7">
                        <select name="header-styling" class="form-control input-sm">
                            <option value="1">default</option>
                            <option value="2">inverse</option>
                        </select>
                    </div>
                </div>
                <div class="row m-t-10">
                    <div class="col-md-5 control-label">Header</div>
                    <div class="col-md-7">
                        <select name="header-fixed" class="form-control input-sm">
                            <option value="1">fixed</option>
                            <option value="2">default</option>
                        </select>
                    </div>
                </div>
                <div class="row m-t-10">
                    <div class="col-md-5 control-label double-line">Sidebar Styling</div>
                    <div class="col-md-7">
                        <select name="sidebar-styling" class="form-control input-sm">
                            <option value="1">default</option>
                            <option value="2">grid</option>
                        </select>
                    </div>
                </div>
                <div class="row m-t-10">
                    <div class="col-md-5 control-label">Sidebar</div>
                    <div class="col-md-7">
                        <select name="sidebar-fixed" class="form-control input-sm">
                            <option value="1">fixed</option>
                            <option value="2">default</option>
                        </select>
                    </div>
                </div>
                <div class="row m-t-10">
                    <div class="col-md-5 control-label double-line">Sidebar Gradient</div>
                    <div class="col-md-7">
                        <select name="content-gradient" class="form-control input-sm">
                            <option value="1">disabled</option>
                            <option value="2">enabled</option>
                        </select>
                    </div>
                </div>
                <div class="row m-t-10">
                    <div class="col-md-5 control-label double-line">Content Styling</div>
                    <div class="col-md-7">
                        <select name="content-styling" class="form-control input-sm">
                            <option value="1">default</option>
                            <option value="2">black</option>
                        </select>
                    </div>
                </div>
                <div class="row m-t-10">
                    <div class="col-md-12">
                        <a href="#" class="btn btn-inverse btn-block btn-sm" data-click="reset-local-storage"><i class="fa fa-refresh m-r-3"></i> Reset Local Storage</a>
                    </div>
                </div>
            </div>
        </div>-->
        <!-- end theme-panel -->
    
    <!-- begin scroll to top btn -->
    <a href="javascript:;" class="btn btn-icon btn-circle btn-success btn-scroll-to-top fade" data-click="scroll-top"><i class="fa fa-angle-up"></i></a>
    <!-- end scroll to top btn -->
  </div>
  <!-- end page container -->
  
  <!-- ================== BEGIN BASE JS ================== -->
  <script src="assets/plugins/jquery/jquery-1.9.1.min.js"></script>
  <script src="assets/plugins/jquery/jquery-migrate-1.1.0.min.js"></script>
  <script src="assets/plugins/jquery-ui/ui/minified/jquery-ui.min.js"></script>
  <script src="assets/plugins/bootstrap/js/bootstrap.min.js"></script>
  <!--[if lt IE 9]>
    <script src="assets/crossbrowserjs/html5shiv.js"></script>
    <script src="assets/crossbrowserjs/respond.min.js"></script>
    <script src="assets/crossbrowserjs/excanvas.min.js"></script>
  <![endif]-->
  <script src="assets/plugins/slimscroll/jquery.slimscroll.min.js"></script>
  <script src="assets/plugins/jquery-cookie/jquery.cookie.js"></script>
  <!-- ================== END BASE JS ================== -->
  
  <!-- ================== BEGIN PAGE LEVEL JS ================== -->
    <script src="assets/plugins/bootstrap3-editable/js/bootstrap-editable.min.js"></script>
  <script src="assets/plugins/bootstrap3-editable/inputs-ext/address/address.js"></script>
  <script src="assets/plugins/bootstrap3-editable/inputs-ext/typeaheadjs/lib/typeahead.js"></script>
  <script src="assets/plugins/bootstrap3-editable/inputs-ext/typeaheadjs/typeaheadjs.js"></script>
  <script src="assets/plugins/bootstrap3-editable/inputs-ext/bootstrap-wysihtml5/wysihtml5.js"></script>
  <script src="assets/plugins/bootstrap3-editable/inputs-ext/bootstrap-wysihtml5/lib/js/wysihtml5-0.3.0.js"></script>
  <script src="assets/plugins/bootstrap3-editable/inputs-ext/bootstrap-wysihtml5/src/bootstrap-wysihtml5.js"></script>
  <script src="assets/plugins/bootstrap3-editable/inputs-ext/bootstrap-datepicker/js/bootstrap-datepicker.js"></script>
  <script src="assets/plugins/bootstrap3-editable/inputs-ext/bootstrap-datetimepicker/js/bootstrap-datetimepicker.min.js"></script>
  <script src="assets/plugins/bootstrap3-editable/inputs-ext/select2/select2.min.js"></script>
  <script src="assets/plugins/mockjax/jquery.mockjax.js"></script>
  <script src="assets/plugins/moment/moment.min.js"></script>
  <script src="assets/js/form-editable.demo.min.js"></script>
  <script src="assets/js/apps.min.js"></script>
  <script src="assets/plugins/bootstrap-wizard/js/bwizard.js"></script>
  <script src="assets/js/form-wizards.demo.min.js"></script>
  <script src="assets/js/apps.min.js"></script>
  <!-- ================== END PAGE LEVEL JS ================== -->
  
  
  <script>
    $(document).ready(function() {
      App.init();
      FormEditable.init();
      FormWizard.init();
    });
  </script>


<script type="text/javascript">
  
var input=  document.getElementById('telefono1');
input.addEventListener('input',function(){
  if (this.value.length > 10) 
     this.value = this.value.slice(0,10); 
})




var input=  document.getElementById('telefono2');
input.addEventListener('input',function(){
  if (this.value.length > 10) 
     this.value = this.value.slice(0,10); 
})

 



</script>>

<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-53034621-1', 'auto');
  ga('send', 'pageview');

</script>
</body>
</html>



<?php 
}else{
 require 'noacceso.php'; 
}


 ?>


 <?php 
}

ob_end_flush();
  ?>

