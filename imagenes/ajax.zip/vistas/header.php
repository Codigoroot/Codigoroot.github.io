 <?php 
if (strlen(session_id())<1) 
  session_start();

  ?>
 <!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Inovatec | Mantenimiento</title>
 <link rel="icon" type="image/css" href="../files/IMI_Logo.png">
  <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <!-- Bootstrap 3.3.7 -->
  <link rel="stylesheet" href="../public/css/bootstrap.min.css">
  <!-- Font Awesome -->

  <link rel="stylesheet" href="../public/css/font-awesome.min.css">

  <link rel="stylesheet" href="../public/css/AdminLTE.min.css">
  <link rel="stylesheet" href="../public/css/_all-skins.min.css">
  <!-- Morris chart --><!-- Daterange picker -->
 
 
<!-- DATATABLES-->
<link rel="stylesheet" href="../public/datatables/jquery.dataTables.min.css">
<link rel="stylesheet" href="../public/datatables/buttons.dataTables.min.css">
<link rel="stylesheet" href="../public/datatables/responsive.dataTables.min.css">
<link rel="stylesheet" href="../public/css/bootstrap-select.min.css">

</head>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">

  <header class="main-header">
    <!-- Logo -->
    <a href="escritorio.php" class="logo">
      <!-- mini logo for sidebar mini 50x50 pixels -->
      <span class="logo-mini"><img src="../files/Tux.png"> </span>
      <!-- logo for regular state and mobile devices -->
      <span class="logo-lg"><h2><b>INOVATEC</b> </h2></span>
    </a>
    <!-- Header Navbar: style can be found in header.less -->
    <nav class="navbar navbar-static-top">
      <!-- Sidebar toggle button-->
      <a href="#" class="sidebar-toggle" data-toggle="push-menu" role="button">
        <span class="sr-only"></span>
      </a>

      <div class="navbar-custom-menu">
        <ul class="nav navbar-nav">

          <li class="dropdown user user-menu">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown">
              <h7>Bienvenido(a):      </h7>
              <span class="hidden-xs"><b> <?php echo ucwords($_SESSION['nombre']); ?> <?php echo ucwords($_SESSION['tipo_documento']); ?> <?php echo ucwords($_SESSION['num_documento']); ?></b> </span>

            </a>
            <ul class="dropdown-menu">
             
              
                <div class="pull-right">
                  <a href="../ajax/usuario.php?op=salir" class="btn btn-default btn-flat">Salir</a>
             
              </li>
            </ul>
          </li>
          <!-- Control Sidebar Toggle Button -->

        </ul>
      </div>
    </nav>
  </header>
  <!-- Left side column. contains the logo and sidebar -->
  <aside class="main-sidebar">
    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">
      <!-- Sidebar user panel -->
     
      <!-- /.search form -->
      <!-- sidebar menu: : style can be found in sidebar.less -->
      <ul class="sidebar-menu" data-widget="tree">

<br>
       <?php 
if ($_SESSION['escritorio']==1) {
  echo ' <li><a href="escritorio.php"><i class="fa fa-home"></i> <span>Inicio</span></a>
        </li>';
}
        ?>

<?php 
if ($_SESSION['consultav']==1) {
  echo ' <li class="treeview">
          <a href="#">
            <i class="fa fa-address-book"></i> <span>Clientes</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="clientes.php"><i class="fa fa-circle-o"></i> Administrar Clientes</a></li>
            
          </ul>
        </li>';

}
        ?>


               <?php 
if ($_SESSION['almacen']==1) {
  echo ' <li class="treeview">
          <a href="#">
            <i class="fa fa-laptop"></i> <span>Administrar Articulos</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="articulo.php"><i class="fa fa-circle-o"></i> Articulos</a></li>
            <li><a href="marca.php"><i class="fa fa-circle-o"></i> Marcas</a></li>
            <li><a href="modelo.php"><i class="fa fa-circle-o"></i> Modelos</a></li>
          </ul>
        </li>';
}
        ?>
               <?php 
if ($_SESSION['compras']==1) {
  echo ' <li class="treeview">
          <a href="#">
            <i class="fa fa-arrow-right"></i> <span>Entrada Equipos</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="entradaEquipo.php"><i class="fa fa-circle-o"></i> Nuevo Equipo</a></li>
          
          </ul>
        </li>';
}
        ?>
        
               <?php 
if ($_SESSION['ventas']==1) {
  echo '<li class="treeview">
          <a href="#">
            <i class="fa fa-cogs"></i> <span>Avances</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="avance.php"><i class="fa fa-circle-o"></i>Agregar Avance</a></li>
          
          </ul>
        </li>';
}
        ?>
 <?php 
if ($_SESSION['consultac']==1) {
  echo '     <li class="treeview">
          <a href="#">
            <i class="fa fa-bar-chart"></i> <span>Reportes</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="reportesporfecha.php"><i class="fa fa-circle-o"></i>Reportes por Fecha</a></li>
             <li><a href="reportesMarca.php"><i class="fa fa-circle-o"></i>Reportes por Marca</a></li>
          </ul>
        </li>';
}
        ?>  
                             <?php 
if ($_SESSION['acceso']==1) {
  echo '  <li class="treeview">
          <a href="#">
            <i class="fa fa-users"></i> <span>Usuarios</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="usuario.php"><i class="fa fa-circle-o"></i> Administrar Usuarios</a></li>
            
          </ul>
        </li>';
}
        ?>  


                                      <?php 
if ($_SESSION['Internet']==1) {
  echo ' <li><a href="reportes.php"><i class="fa fa-file-text "></i> <span>Reportes de Impresión</span></a>
        </li>';
}
        ?>


        <?php 
if ($_SESSION['Internet']==1) {
  echo ' <li><a href="contratos.php"><i class="fa fa-file-text "></i> <span>Contratos de Internet</span></a>
        </li>';
}
        ?>
            
        
         
        <li>
            
                <a href="">
                  <h6>
                    <i class="fa fa-code">
                    </i>
                      <span> por: Javier Aguilar
                      </span>
                   </h6>
                </a>
        </li>
        
        
        
      </ul>
    </section>
    <!-- /.sidebar -->

  </aside>